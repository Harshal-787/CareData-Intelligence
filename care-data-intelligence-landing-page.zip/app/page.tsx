import LandingPageV2 from '@/components/landing-page-v2'

export default function Page() {
  return <LandingPageV2 />
}
